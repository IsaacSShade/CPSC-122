/*
 Name: Aiden Tabrah
 Class: CPSC 122, Spring 2023
 Date: March 21, 2023
 Programming Assignment: PA5                                                                  
 Description: A user interface for managing song libraries and making edits to them
*/

#include "PA5.h"

int main() {
	runMusicManager();

	return 0;
}