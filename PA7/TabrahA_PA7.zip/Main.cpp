/*
 Name: Aiden Tabrah
 Class: CPSC 122, Spring 2023
 Date: April 18, 2023
 Programming Assignment: PA7                                                           
 Description: With values assigned to different uppercase letters in "input.txt", it displays both the equation's infix & postfix equations and the result.
*/

#include "PA7.h"

int main() {
	runProgram("input.txt");
	return 0;
}