#include "PA8.h"

// no need for any changes here
int main() {
	runPrimesPrompt();
	
	return 0;
}