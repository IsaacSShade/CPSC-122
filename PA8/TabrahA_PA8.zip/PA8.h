#ifndef PA8_H
#define PA8_H

#include <iostream>
#include "Sieve.h"

using namespace std;

void runPrimesPrompt();

#endif