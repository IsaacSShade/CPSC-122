/*
 Name: Aiden Tabrah
 Class: CPSC 122, Spring 2023
 Date: May 6, 2023
 Programming Assignment: PA9                                                          
 Description: Main function for running everything
*/

#include "PA9.h"

// no need for any changes here
int main() {
	runTask1();
	runTask2();
	runTask3();
	runTask4();
	runTask5();
	
	runBONUSTask();

	return 0;
}