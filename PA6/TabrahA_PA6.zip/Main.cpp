/*
 Name: Aiden Tabrah
 Class: CPSC 122, Spring 2023
 Date: April 4, 2023
 Programming Assignment: PA6                                                                  
 Description: A user interface for managing song libraries and making edits to them using linked lists
*/

#include "PA6.h"

int main() {
	runMusicManager();

	return 0;
}